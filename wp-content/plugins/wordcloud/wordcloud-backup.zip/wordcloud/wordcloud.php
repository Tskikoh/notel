<?php
/*
Plugin Name: ワードクラウド
Plugin URI: 
Description: ワードクラウドでワードプレスの記事の単語頻出度を可視化するためのプラグインです。
Author: 伊井　勝利
Version: 0.1.7
Author URI: https://tsukiko.com/
Text Domain: wordcloud
Domain Path: /languages
*/
$scnum = 1;

if ( ! class_exists( 'Word_Cloud' ) ) :
	class Word_Cloud {
		var $admin_options_name = 'WordCloud_options';
		var $shared_post = null;

		function __construct() {
			add_action( 'init', array( $this, 'init' ) );
		}

		function init() {
			global $current_user;
			add_action( 'admin_menu', array( $this, 'add_admin_pages' ) );
			add_filter( 'the_posts', array( $this, 'the_posts_intercept' ) );
			add_filter( 'posts_results', array( $this, 'posts_results_intercept' ) );

			$this->admin_options = $this->get_admin_options();
			$this->admin_options = $this->clear_expired( $this->admin_options );
			$this->user_options = array();
			if ( $current_user->ID > 0 && isset( $this->admin_options[ $current_user->ID ] ) ) {
				$this->user_options = $this->admin_options[ $current_user->ID ];
			}
			$this->save_admin_options();
			load_plugin_textdomain( 'wordcloud', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );

			if ( isset( $_GET['page'] ) && $_GET['page'] === plugin_basename( __FILE__ ) ) {
				$this->admin_page_init();
			}
		}

		function admin_page_init() {
			wp_enqueue_script( 'jquery' );
			add_action( 'admin_head', array( $this, 'print_admin_css' ) );
			add_action( 'admin_head', array( $this, 'print_admin_js' ) );
		}

		function get_admin_options() {
			$saved_options = get_option( $this->admin_options_name );
			return is_array( $saved_options )? $saved_options : array();
		}

		function save_admin_options() {
			global $current_user;
			if ( $current_user->ID > 0 ) {
				$this->admin_options[ $current_user->ID ] = $this->user_options;
			}
			update_option( $this->admin_options_name, $this->admin_options );
		}

		function clear_expired( $all_options ) {
			$all = array();
			foreach ( $all_options as $user_id => $options ) {
				$shared = array();
				if ( ! isset( $options['shared'] ) || ! is_array( $options['shared'] ) ) {
					continue;
				}
				foreach ( $options['shared'] as $share ) {
					if ( $share['expires'] < time() ) {
						continue;
					}
					$shared[] = $share;
				}
				$options['shared'] = $shared;
				$all[ $user_id ] = $options;
			}
			return $all;
		}

		function add_admin_pages() {
			add_submenu_page( 'edit.php', __( 'ワードクラウド', 'wordcloud' ), __( 'ワードクラウド', 'wordcloud' ),
			'edit_posts', __FILE__, array( $this, 'output_existing_menu_sub_admin_page' ) );
		}

		function calculate_seconds( $params ) {
			$exp = 60;
			$multiply = 60;
			if ( isset( $params['expires'] ) && ( $e = intval( $params['expires'] ) ) ) {
				$exp = $e;
			}
			$mults = array(
				'm' => MINUTE_IN_SECONDS,
				'h' => HOUR_IN_SECONDS,
				'd' => DAY_IN_SECONDS,
				'w' => WEEK_IN_SECONDS,
			);
			if ( isset( $params['measure'] ) && isset( $mults[ $params['measure'] ] ) ) {
				$multiply = $mults[ $params['measure'] ];
			}
			return $exp * $multiply;
		}

		function process_new_share( $params ) {
			global $current_user;
			if ( isset( $params['post_id'] ) ) {
				$p = get_post( $params['post_id'] );
				if ( ! $p ) {
					return __( 'そのような投稿はありません！', 'wordcloud' );
				}
				if ( 'publish' === get_post_status( $p ) ) {
					return __( '投稿は公開されています！', 'wordcloudt' );
				}
				if ( ! current_user_can( 'edit_post', $p->ID ) ) {
					return __( '申し訳ありませんが、編集できない投稿を共有することはできません。', 'wordcloud' );
				}
				$this->user_options['shared'][] = array(
					'id' => $p->ID,
					'expires' => time() + $this->calculate_seconds( $params ),
					'key' => uniqid( 'baba' . $p->ID . '_' ),
				);
				$this->save_admin_options();
			}
		}

		function process_delete( $params ) {
			if ( ! isset( $params['key'] ) ||
			! isset( $this->user_options['shared'] ) ||
			! is_array( $this->user_options['shared'] ) ) {
				return '';
			}
			$shared = array();
			foreach ( $this->user_options['shared'] as $share ) {
				if ( $share['key'] === $params['key'] ) {
					if ( ! current_user_can( 'edit_post', $share['id'] ) ) {
						return __( '申し訳ありませんが、編集できない投稿を共有することはできません。', 'wordcloud' );
					}
					continue;
				}
				$shared[] = $share;
			}
			$this->user_options['shared'] = $shared;
			$this->save_admin_options();
		}

		function process_extend( $params ) {
			if ( ! isset( $params['key'] ) ||
			! isset( $this->user_options['shared'] ) ||
			! is_array( $this->user_options['shared'] ) ) {
				return '';
			}
			$shared = array();
			foreach ( $this->user_options['shared'] as $share ) {
				if ( $share['key'] === $params['key'] ) {
					if ( ! current_user_can( 'edit_post', $share['id'] ) ) {
						return __( '申し訳ありませんが、編集できない投稿を共有することはできません。', 'wordcloud' );
					}
					$share['expires'] += $this->calculate_seconds( $params );
				}
				$shared[] = $share;
			}
			$this->user_options['shared'] = $shared;
			$this->save_admin_options();
		}

		function get_drafts() {
			global $current_user;
			$unpublished_statuses = array( 'pending', 'draft', 'future', 'private' );
			$my_unpublished = get_posts( array(
				'post_status' => $unpublished_statuses,
				'author' => $current_user->ID,
				// some environments, like WordPress.com hook on those filters
				// for an extra caching layer
				'suppress_filters' => false,
			) );
			$others_unpublished = get_posts( array(
				'post_status' => $unpublished_statuses,
				'author' => -$current_user->ID,
				'suppress_filters' => false,
				'perm' => 'editable',
			) );
			$draft_groups = array(
			array(
				'label' => __( '自分の下書き:', 'wordcloud' ),
				'posts' => $my_unpublished,
			),
			array(
				'label' => __( '他の投稿:', 'wordcloud' ),
				'posts' => $others_unpublished,
			),
			);
			return $draft_groups;
		}

		function get_shared() {
			if ( ! isset( $this->user_options['shared'] ) || ! is_array( $this->user_options['shared'] ) ) {
				return array();
			}
			return $this->user_options['shared'];
		}

		function friendly_delta( $s ) {
			$m = (int) ( $s / MINUTE_IN_SECONDS );
			$h = (int) ( $s / HOUR_IN_SECONDS );
			$free_m = (int) ( ( $s - $h * HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );
			$d = (int) ( $s / DAY_IN_SECONDS );
			$free_h = (int) ( ( $s - $d * DAY_IN_SECONDS ) / HOUR_IN_SECONDS );
			if ( $m < 1 ) {
				$res = array();
			} elseif ( $h < 1 ) {
				$res = array( $m );
			} elseif ( $d < 1 ) {
				$res = array( $free_m, $h );
			} else {
				$res = array( $free_m, $free_h, $d );
			}
			$names = array();
			if ( isset( $res[0] ) ) {
				$names[] = sprintf( _n( '%d分', '%d分', $res[0], 'wordcloud' ), $res[0] );
			}
			if ( isset( $res[1] ) ) {
				$names[] = sprintf( _n( '%d時間', '%d時間', $res[1], 'wordcloud' ), $res[1] );
			}
			if ( isset( $res[2] ) ) {
				$names[] = sprintf( _n( '%d日', '%d日', $res[2], 'wordcloud' ), $res[2] );
			}
			return implode( '', array_reverse( $names ) );
		}

		function output_existing_menu_sub_admin_page() {
			$msg = '';
			if ( isset( $_POST['wordcloud_submit'] ) ) {
				check_admin_referer( 'wordcloud-new-share' );
				$msg = $this->process_new_share( $_POST );
			} elseif ( isset( $_POST['action'] ) && $_POST['action'] === 'extend' ) {
				check_admin_referer( 'wordcloud-extend' );
				$msg = $this->process_extend( $_POST );
			} elseif ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' ) {
				check_admin_referer( 'wordcloud-delete' );
				$msg = $this->process_delete( $_GET );
			}
			$draft_groups = $this->get_drafts();
	?>
	<div class="wrap">
		<h2><?php _e( 'ワードクラウド', 'wordcloud' ); ?></h2>
<?php 	if ( $msg ) :?>
		<div id="message" class="updated fade"><?php echo $msg; ?></div>
<?php 	endif;?>
		<?php
			$key = '8w1VJFg9uGfmZ6ZZv45HYkDSFOzECHPyB2ZsVGAY';
			$plain_text = wp_get_current_user() -> user_login;
			
			//openssl
			$c_t = openssl_encrypt($plain_text, 'AES-128-ECB', $key);
			//var_dump($plain_text, $c_t, $p_t);
		?>
		<h1 style="color: red;">
			プラグインの調整中
		</h1>

		<h3>自動で開かない場合は<a href="/wp-content/plugins/wordcloud/tool.php?user=<?= urlencode($c_t) ?>" target="_blank">こちら</a>をクリック
			<?php //_e( 'ワードクラウド', 'wordcloud' ); ?></h3>
		<div class="container">
			<div id="timer">読み込み中…</div>
		</div>
		<script type="text/javascript">
			alert("プラグインの調整中\n利用出来ません");
			window.open('/wp-content/plugins/wordcloud/tool.php?user=<?= urlencode($c_t) ?>');
			window.onload=function(){
				var count = 10000;
				var id = setInterval(function(){
					count--;
					document.querySelector('#timer').textContent=count+1+"秒後に前のページに戻ります。";
					if(count <= 0) {
						clearInterval(id);
						window.history.back();
					}
				},1000);
			}
		</script><br />
		<a href='#' onclick='javascript:window.history.back();'>前のページへ戻る</a>
		
		<hr /><!--<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />
		<hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr /><hr />-->
		

		
 
<script>
 
// ボタンの要素を取得
var button = document.getElementById("button");
 
// ボタンをクリックした時の処理
button.addEventListener("click", function(e) {
 
    e.preventDefault();
 
    // 入力フォームの値を取得
    var textForm1 = document.getElementsByName("method").value;
    var textForm2 = document.getElementById("KeywordCheckUrl").value;
 
    // 取得した値を別の入力フォームに表示
    var resultForm1 = document.getElementById("method2");
    var resultForm2 = document.getElementById("KeywordCheckUrl2");
    resultForm.value = textForm;
    resultForm1.value = textForm1;
    resultForm2.value = textForm2;
});
 
</script>
		<!-- edit.php?page=wordcloud%2Fwordcloud.php　-->
		<form id="webForm" method="post" accept-charset="utf-8"><div style="display:none;"><input type="hidden" name="method" value="POST" kl_vkbd_parsed="true"></div><table class="table table-striped table-responsive">
<thead><tr><th width="150">項目</th><th>内容</th><th>備考</th></tr></thead><tbody>
<!--<tr><td>チェックURL</td><td>
<label for="KeywordCheckUrl"></label>--><input name="url" style="width:300px" maxlength="50" type="hidden" value="<?php echo $shorten_url; ?>" id="KeywordCheckUrl" kl_vkbd_parsed="true"><!--</td><td>http/httpsで始まるURLを指定してください。50Bytesまで指定可能です。</td></tr>-->
<tr><td>UserAgent</td><td>
<select name="useragent" id="KeywordCheckUseragent">
<option value="">項目を選択してください</option>
<option value="iPhone_iOS6">iPhone iOS 6</option>
<option value="iPad_iOS6">iPad iOS 6</option>
<option value="Google_Chrome_37" selected="selected">Google Chrome 37</option>
<option value="Android_OS_4x">Android OS 4.x</option>
<option value="IE_11">Internet Explorer 11</option>
</select></td><td>ユーザーエージェントを指定してください。</td></tr>
<tr><td>キーワード出現頻度</td><td>
<select name="appearances" id="KeywordCheckAppearances">
<option value="">項目を選択</option>
<option value="1" selected="selected">1回以上</option>
<option value="2">2回以上</option>
<option value="3">3回以上</option>
<option value="4">4回以上</option>
<option value="5">5回以上</option>
<option value="6">6回以上</option>
<option value="7">7回以上</option>
<option value="8">8回以上</option>
<option value="9">9回以上</option>
<option value="10">10回以上</option>
</select></td><td>キーワード出現頻度を指定してください。</td></tr>
<tr><td>キーワード出現順位</td><td>
<select name="displayno" id="KeywordCheckDisplayno">
<option value="">項目を選択</option>
<option value="10">上位 No.10まで</option>
<option value="20">上位 No.20まで</option>
<option value="30">上位 No.30まで</option>
<option value="40">上位 No.40まで</option>
<option value="50">上位 No.50まで</option>
<option value="60">上位 No.60まで</option>
<option value="70">上位 No.70まで</option>
<option value="80">上位 No.80まで</option>
<option value="90">上位 No.90まで</option>
<option value="100">上位 No.100まで</option>
<option value="150">上位 No.150まで</option>
<option value="200" selected="selected">上位 No.200まで</option>
</select></td><td>キーワード出現順位を指定してください。</td></tr>
<tr><td>ワードクラウド種別</td><td>
<input type="radio" name="pattern" id="KeywordCheckPattern1" value="1" checked="checked" kl_vkbd_parsed="true"><label for="KeywordCheckPattern1">フラット</label><input type="radio" name="pattern" id="KeywordCheckPattern2" value="2" kl_vkbd_parsed="true"><label for="KeywordCheckPattern2">フラット＋直角</label><input type="radio" name="pattern" id="KeywordCheckPattern3" value="3" kl_vkbd_parsed="true"><label for="KeywordCheckPattern3">傾き</label></td><td>ワードクラウドの表示種別を指定してください。</td></tr>
<tr><td>ワードクラウドサイズ</td><td>
横幅：<select name="imgw" id="KeywordCheckImgw">
<option value="">項目を選択</option>
<option value="200">200</option>
<option value="300">300</option>
<option value="400">400</option>
<option value="500">500</option>
<option value="600">600</option>
<option value="700">700</option>
<option value="800">800</option>
<option value="900">900</option>
<option value="999" selected="selected">画面幅</option>
</select>　縦幅：<select name="imgh" id="KeywordCheckImgh">
<option value="">項目を選択</option>
<option value="200">200</option>
<option value="300">300</option>
<option value="400" selected="selected">400</option>
<option value="500">500</option>
<option value="600">600</option>
<option value="700">700</option>
<option value="800">800</option>
<option value="900">900</option>
</select></td><td>ワードクラウドのSVGサイズ（横幅・縦幅）を指定してください。</td></tr>
<tr><td>文字サイズ</td><td>
最少：<select name="minrange" id="KeywordCheckMinrange">
<option value="">項目を選択</option>
<option value="10">10</option>
<option value="12">12</option>
<option value="14" selected="selected">14</option>
<option value="16">16</option>
<option value="18">18</option>
<option value="20">20</option>
</select>最大：<select name="maxrange" id="KeywordCheckMaxrange">
<option value="">項目を選択</option>
<option value="50">50</option>
<option value="60">60</option>
<option value="70">70</option>
<option value="80" selected="selected">80</option>
<option value="90">90</option>
<option value="100">100</option>
</select></td><td>ワードクラウド内の文字サイズ（最少・最大）を指定できます。</td></tr>
</tbody></table>

<script type="text/javascript">
$(function(){
  $("#exslideBox").hide();
  $(".exopentable").click(function(){
    $("#exslideBox").slideToggle("slow");
  });
});
</script>
<p class="exopentable"><i class="fa-fw fa fa-wrench" style="color:black;"></i><!--除外ワードを指定したい場合、本テキスト部をクリックしてください。--></p>
<div id="exslideBox" style="display: none;">
<table class="table table-striped table-responsive">
<thead><tr><th width="150">項目</th><th>除外ワード</th><th>備考</th></tr></thead><tbody>
<tr><td>除外ワード1</td><td>
<label for="KeywordExclusion1"></label><input name="data[Keyword][exclusion1]" style="width:200px" maxlength="120" type="text" value="" id="KeywordExclusion1" kl_vkbd_parsed="true"></td><td>除外ワードがあれば指定してください。</td></tr>
<tr><td>除外ワード2</td><td>
<label for="KeywordExclusion2"></label><input name="data[Keyword][exclusion2]" style="width:200px" maxlength="120" type="text" value="" id="KeywordExclusion2" kl_vkbd_parsed="true"></td><td>除外ワードがあれば指定してください。</td></tr>
<tr><td>除外ワード3</td><td>
<label for="KeywordExclusion3"></label><input name="data[Keyword][exclusion3]" style="width:200px" maxlength="120" type="text" value="" id="KeywordExclusion3" kl_vkbd_parsed="true"></td><td>除外ワードがあれば指定してください。</td></tr>
</tbody></table>
</div>

<!-- <div class="submit"><input type="submit" value="Check" kl_vkbd_parsed="true"></div></form -->
			
        <button id="button">取得する</button>
		</form>
		株式会社ファンブライトのページに遷移します。
<?php 
			if($_SERVER["REQUEST_METHOD"] == "POST"){
/*				?><div style="margin:0px;padding:10px;line-height:1.3;overflow:auto;border:2px groove #696969;text-align:left;font-size:100%;height:50em;scrollbar-base-color:#696969;"><?php 
				echo nl2br( htmlspecialchars( $contents ) ); 
								echo "</div>";
*/
				echo $contents; 
	/*	?>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/jquery-1.10.2.min.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/d3.v3.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/rgbcolor.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/StackBlur.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/canvg.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/FileSaver.min.js?1449934354"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/canvas-toBlob.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/lib/d3.layout.cloud.js?1449934355"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/d3wordcloud.js?1449934354"></script>
		<script type="text/javascript" src="https://lab.fanbright.jp/js/downloadimage.js?1449934354"></script>
		<?php */
			}
		?>
		
		
		<!--
		<span id="textSpan"></span>
		<table class="widefat">
			<thead>
			<tr>
				<th><?php _e( 'ID', 'wordcloud' ); ?></th>
				<th><?php _e( 'タイトル', 'wordcloud' ); ?></th>
				<th><?php _e( 'リンク', 'wordcloud' ); ?></th>
				<th><?php _e( '残り時間', 'wordcloud' ); ?></th>
				<th colspan="2" class="actions"><?php _e( '操作', 'wordcloud' ); ?></th>
			</tr>
			</thead>
			<tbody>
			-->
<?php
		$s = $this->get_shared();
foreach ( $s as $share ) :
	$p = get_post( $share['id'] );
	$url = get_bloginfo( 'url' ) . '/?p=' . $p->ID . '&wordcloud=' . $share['key'];
	//$url = str_replace('http://', 'https://', $url);
	//$esc_url = esc_url( $url )
	$friendly_delta = $this->friendly_delta( $share['expires'] - time() );
	$iso_expires = date_i18n( 'c', $share['expires'] );
?>
		<!--
<tr>
<td><?php echo $p->ID; ?></td>
<td><?php echo $p->post_title; ?></td>
<-- TODO: make the draft link selecatble >
<td><a href="<?php echo esc_url( $url ); ?>" target="_blank">開く</a>・
	<a href="#<?php if($scnum==""){$scnum=1;} echo $scnum; ?>" id="copy<?php echo $scnum; $scnum++; ?>">コピー</a>
	<script type="text/javascript" language="javascript">
		function execCopy(string){
  var temp = document.createElement('div');
  
  temp.appendChild(document.createElement('pre')).textContent = string;
  
  var s = temp.style;
  s.position = 'fixed';
  s.left = '-100%';
  
  document.body.appendChild(temp);
  document.getSelection().selectAllChildren(temp);
  
  var result = document.execCommand('copy');

  document.body.removeChild(temp);
  // true なら実行できている falseなら失敗か対応していないか
  return result;
}

var copy = document.getElementById('copy<?php echo $scnum - 1; ?>');

copy.onclick = function(){
  if(execCopy("<?php echo esc_url( $url ); ?>")){
	  var span = document.getElementById("textSpan");
    span.textContent = "ID<?php echo $share['id'] ?>の共有リンクをコピーしました。";
    var text = span.textConten
	//3000ミリ秒（3秒）後に関数「syori()」を呼び出す;
	setTimeout("syori()", 2000);
  }
  else {
    alert('このブラウザではコピーに対応していません');
  }
};
		function syori(){
	  var span = document.getElementById("textSpan");
    span.textContent = "";
    var text = span.textContent;
		}
	</script>
-->
	<?php /*
		$lineMessage = <<< EOM
ノートる（お遊び用で）、共有リンクを発行しましたので暇な時間に見てください。
%URL
EOM;

		$mailTitle = <<< EOM
ノートる（お遊び用で）、共有リンクを発行しました。
EOM;

		$mailMessage = <<< EOM
暇な時間に見てください。
URL: %URL
EOM;

		$lineMessage = str_replace('%URL', $url, $lineMessage);
		$mailTitle = str_replace('%URL', $url, $mailTitle);
		$mailMessage = str_replace('%URL', $url, $mailMessage);
		*/
	?><!--
	<div class="line-it-button" data-lang="ja" data-type="share-a" data-url="<?php echo urlencode( $lineMessage ); ?>" style="display: none;"></div>
 <script src="https://d.line-scdn.net/r/web/social-plugin/js/thirdparty/loader.min.js" async="async" defer="defer"></script>
	<a href="mailto:?subject=<?php echo urlencode( $mailTitle ); ?>&amp;body=<?php echo urlencode( $mailMessage ); ?>"><img src="https://icon-rainbow.com/i/icon_02440/icon_024400.svg" width="20px" /></a>
</td>
<td><time title="<?php echo $iso_expires; ?>" datetime="<?php echo $iso_expires; ?>"><?php echo $friendly_delta; ?></time></td>
<td class="actions">
	<a class="wordcloud-extend edit" id="wordcloud-extend-link-<?php echo $share['key']; ?>"
		href="javascript:wordcloud.toggle_extend( '<?php echo $share['key']; ?>' );">
			<?php _e( '延長', 'wordcloud' ); ?>
	</a>
	<form class="wordcloud-extend" id="wordcloud-extend-form-<?php echo $share['key']; ?>"
		action="" method="post">
		<input type="hidden" name="action" value="extend" />
		<input type="hidden" name="key" value="<?php echo $share['key']; ?>" />
<?php _e( '延長期間', 'wordcloud' );?>
<?php echo $this->tmpl_measure_select(); ?>
		<input type="submit" class="button" name="wordcloud_extend_submit"
			value="<?php echo esc_attr__( '追加', 'wordcloud' ); ?>"/>
		<a class="wordcloud-extend-cancel"
			href="javascript:wordcloud.cancel_extend( '<?php echo $share['key']; ?>' );">
			<?php _e( 'キャンセル', 'wordcloud' ); ?>
		</a>
		<?php wp_nonce_field( 'wordcloud-extend' ); ?>
	</form>
</td>
<td class="actions">
-->
<?php
	//$delete_url = 'edit.php?page=' . plugin_basename( __FILE__ ) . '&action=delete&key=' . $share['key'];
	//$nonced_delete_url = wp_nonce_url( $delete_url, 'wordcloud-delete' );
?><!--
	<a class="delete" href="<?php echo esc_url( $nonced_delete_url ); ?>"><?php _e( '削除', 'wordcloud' ); ?></a>
</td>
</tr>-
<?php 
		endforeach;
if ( empty( $s ) ) : 
?>
<tr>
<td colspan="5"><?php //_e( '共有しているノートはありません', 'wordcloud' ); ?></td>
</tr>
<?php
		endif;
?>
			</tbody>
		</table>
<!--
		<h3><?php //_e( 'ワードクラウドを作成', 'wordcloud' ); ?></h3>
		<form id="wordcloud-share" action="" method="post">
		<p>
			<select id="wordcloud-postid" name="post_id">
			<option value=""><?php //_e( 'ノートを選択', 'wordcloud' ); ?></option>
<?php
foreach ( $draft_groups as $draft_group ) :
	if ( $draft_group['posts'] ) :
?>
	<option value="" disabled="disabled"></option>
	<option value="" disabled="disabled"><?php echo $draft_group['label']; ?></option>
<?php
foreach ( $draft_group['posts'] as $draft ) :
	if ( empty( $draft->post_title ) ) {
		continue;
	}
?>
<option value="<?php echo $draft->ID?>"><?php echo esc_html( $draft->post_title ); ?></option>
<?php
		endforeach;
endif;
		endforeach;
?>
			</select>
		</p>
		<p>
			<?php _e( '期間', 'wordcloud' ); ?>
			<?php echo $this->tmpl_measure_select(); ?>
			<input type="submit" class="button" name="wordcloud_submit"
				value="<?php echo esc_attr__( '共有する', 'wordcloud' ); ?>" />
		</p>
		<?php wp_nonce_field( 'wordcloud-new-share' ); ?>
		</form>
		</div>-->
<?php
		}

		function can_view( $post_id ) {
			if ( ! isset( $_GET['wordcloud'] ) || ! is_array( $this->admin_options ) ) {
				return false;
			}
			foreach ( $this->admin_options as $option ) {
				if ( ! is_array( $option ) || ! isset( $option['shared'] ) ) {
					continue;
				}
				$shares = $option['shared'];
				foreach ( $shares as $share ) {
					if ( $share['id'] === $post_id && $share['key'] === $_GET['wordcloud'] ) {
						return true;
					}
				}
			}
			return false;
		}

		function posts_results_intercept( $posts ) {
			if ( 1 !== count( $posts ) ) {
				return $posts;
			}
			$post = $posts[0];
			$status = get_post_status( $post );
			if ( 'publish' !== $status && $this->can_view( $post->ID ) ) {
				$this->shared_post = $post;
			}
			return $posts;
		}

		function the_posts_intercept( $posts ) {
			if ( empty( $posts ) && ! is_null( $this->shared_post ) ) {
				return array( $this->shared_post );
			} else {
				$this->shared_post = null;
				return $posts;
			}
		}

		function tmpl_measure_select() {
			$mins = __( '分', 'wordcloud' );
			$hours = __( '時間', 'wordcloud' );
			$days = __( '日', 'wordcloud' );
			$weeks = __( '週間', 'wordcloud' );
			return <<<SELECT
			<input name="expires" type="text" value="1" size="2"/>
			<select name="measure">
				<option value="m">$mins</option>
				<option value="h">$hours</option>
				<option value="d">$days</option>
				<option value="w" selected>$weeks</option>
			</select>
SELECT;
		}

		function print_admin_css() {
	?>
	<style type="text/css">
		a.wordcloud-extend, a.wordcloud-extend-cancel { display: none; }
		form.wordcloud-extend { white-space: nowrap; }
		form.wordcloud-extend, form.wordcloud-extend input, form.wordcloud-extend select { font-size: 11px; }
		th.actions, td.actions { text-align: center; }
	</style>
	<?php
		}

		function print_admin_js() {
	?>
	<script type="text/javascript">
	//<![CDATA[
	( function( $ ) {
		$( function() {
			$( 'form.wordcloud-extend' ).hide();
			$( 'a.wordcloud-extend' ).show();
			$( 'a.wordcloud-extend-cancel' ).show();
			$( 'a.wordcloud-extend-cancel' ).css( 'display', 'inline' );
		} );
		window.wordcloud = {
			toggle_extend: function( key ) {
				$( '#wordcloud-extend-form-'+key ).show();
				$( '#wordcloud-extend-link-'+key ).hide();
				$( '#wordcloud-extend-form-'+key+' input[name="expires"]' ).focus();
			},
			cancel_extend: function( key ) {
				$( '#wordcloud-extend-form-'+key ).hide();
				$( '#wordcloud-extend-link-'+key ).show();
			}
		};
	} )( jQuery );
	//]]>
	</script>
	<?php
		}
	}
endif;

if ( class_exists( 'Word_Cloud' ) ) {
	$__word_cloud = new Word_Cloud();
}
